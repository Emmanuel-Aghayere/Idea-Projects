package sample;
import  sample.datamodel.TodoItem;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    private List<TodoItem> todoItems;
    public void initialize(){
        TodoItem item1 = new TodoItem("Study","Study for Java 2", LocalDate.of(2022, Month.SEPTEMBER,22));
        TodoItem item2 = new TodoItem("Drink Whiskey","Drink whiskey at Happy hour",LocalDate.of(2022,9,22));
        TodoItem item3 = new TodoItem("Walk Dog","Taking my cute dog for a nice walk", LocalDate.of(2022,9,22));
        TodoItem item4 = new TodoItem("Sleep Time","Getting a goodnight sleep",LocalDate.of(2022,9,22));
        TodoItem item5 = new TodoItem("Wake up","Wake up to see the sunrise",LocalDate.of(2022,9,22));
        todoItems = new ArrayList<TodoItem>();
        todoItems.add(item1);
        todoItems.add(item2);
        todoItems.add(item3);
        todoItems.add(item4);
        todoItems.add(item5);


    }

}
